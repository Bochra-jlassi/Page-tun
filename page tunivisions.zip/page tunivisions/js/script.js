document.getElementById("butt").addEventListener("click",f1)
function f1()
{
  
var x = document.getElementById("x1").value ;
if (x==("ombre"))
{
  
    window.location.replace("http://www.google.com");
}
}